
const ball = document.querySelector('.ball');
const paddle1 = document.querySelector('.player1');
const paddle2 = document.querySelector('.player2');

let ballX = 50; 
let ballY = 50; 
let ballSpeedX = 0.5; 
let ballSpeedY = 0.3; 

let paddle1Y = 50;
let paddle2Y = 50; 
const paddleSpeed = 2; 


let keys = {};
document.addEventListener('keydown', (e) => keys[e.key] = true);
document.addEventListener('keyup', (e) => keys[e.key] = false);


function updateBall() {
    ballX += ballSpeedX;
    ballY += ballSpeedY;

    if (ballY <= 0 || ballY >= 100) ballSpeedY *= -1;

    if (ballX <= 3 && ballY > paddle1Y - 10 && ballY < paddle1Y + 10) ballSpeedX *= -1;
    if (ballX >= 97 && ballY > paddle2Y - 10 && ballY < paddle2Y + 10) ballSpeedX *= -1;

    if (ballX <= 0 || ballX >= 100) resetBall();

    ball.style.left = ballX + '%';
    ball.style.top = ballY + '%';
}

function resetBall() {
    ballX = 50;
    ballY = 50;
    ballSpeedX *= -1; 
}

function updatePaddles() {
    if (keys['w'] && paddle1Y > 0) paddle1Y -= paddleSpeed; 
    if (keys['s'] && paddle1Y < 100) paddle1Y += paddleSpeed; 
    if (keys['ArrowUp'] && paddle2Y > 0) paddle2Y -= paddleSpeed; 
    if (keys['ArrowDown'] && paddle2Y < 100) paddle2Y += paddleSpeed; 

    paddle1.style.top = paddle1Y + '%';
    paddle2.style.top = paddle2Y + '%';
}

function gameLoop() {
    updateBall();
    updatePaddles();
    requestAnimationFrame(gameLoop); 
}

gameLoop();
